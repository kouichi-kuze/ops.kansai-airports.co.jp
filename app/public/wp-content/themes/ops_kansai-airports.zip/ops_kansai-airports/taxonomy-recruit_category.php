<?php get_template_part( 'inc/header' ); ?>
<div class="breadcrumb-wrap">
    <?php get_template_part( 'inc/breadcrumb' ); ?>
</div>
<?php get_template_part( 'inc/footer' ); ?>