	<div class="recruit-bnr-content">
		<div class="p-side-15-8">
			<div class="max-128">
				<!--slide-->
				<section class="recruit-bnr-content">
					<a href="<?php echo home_url( '/' ); ?>recruit/" class="recruit-bnr-link">
						<div class="recruit-bnr-slider-outer">
							<div class="btn_recruit-bnr-slider-pc">
								<img src="<?php bloginfo('template_url'); ?>/assets/img/common/btn_recruit-bnr-slider_pc.png" alt="">
							</div>
							<div class="btn_recruit-bnr-slider-sp">
								<img src="<?php bloginfo('template_url'); ?>/assets/img/common/btn_recruit-bnr-slider_sp.png" alt="">
							</div>
							
							
							<!--/slider-->
							<ul class="recruit-bnr-slider">
							<li><img src="<?php bloginfo('template_url'); ?>/assets/img/common/slide_01.png" alt=""></li>
							<li><img src="<?php bloginfo('template_url'); ?>/assets/img/common/slide_02.png" alt=""></li>
							<li><img src="<?php bloginfo('template_url'); ?>/assets/img/common/slide_03.png" alt=""></li>
							<li><img src="<?php bloginfo('template_url'); ?>/assets/img/common/slide_04.png" alt=""></li>
							<li><img src="<?php bloginfo('template_url'); ?>/assets/img/common/slide_05.png" alt=""></li>
							<li><img src="<?php bloginfo('template_url'); ?>/assets/img/common/slide_06.png" alt=""></li>
							</ul>		
						</div>
					</a>
				</section>
			<!--service-->

			</div>
		</div>
	</div>
