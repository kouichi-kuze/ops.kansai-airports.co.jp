		<div class="footer-bnr-content bg-color-primary">
			<div class="p-side-15-8">
				<div class="max-138">
					<ul class="bnr-requruit">
						<a href="<?php echo home_url( '/' ); ?>">
							<li class="img">
								<img src="<?php bloginfo('template_url'); ?>/assets/img/recruit/bnr_reqruit_pc.png" alt="採用サイト（新卒・中途）空港内のさまざまなフィールドで活躍している先輩たちの担当業務や入社動機などをご紹介。" class="d-md-block">
								<img src="<?php bloginfo('template_url'); ?>/assets/img/recruit/bnr_reqruit_sp.png" alt="採用サイト（新卒・中途）空港内のさまざまなフィールドで活躍している先輩たちの担当業務や入社動機などをご紹介。" class="d-md-none">
							</li>
							<li class="bnr-requruit-btn">
								<div class="btn-over">
									<span class="btn-bg"></span>
									<span class="btn-text">募集要項・エントリー</span>
								</div>
								
							</li>
						</a>
					</ul>
					<div class="bnr-voice">
						<a href="<?php echo home_url( '/' ); ?>">
							<div class="bnr-voice-btn">
								<img src="<?php bloginfo('template_url'); ?>/assets/img/recruit/bnr_voice_pc.png" alt="先輩の声　空港内のさまざまなフィールドで活躍している先輩たちの担当業務や入社動機などをご紹介。" class="d-md-block">
								<img src="<?php bloginfo('template_url'); ?>/assets/img/recruit/bnr_voice_sp.png" alt="先輩の声　空港内のさまざまなフィールドで活躍している先輩たちの担当業務や入社動機などをご紹介。" class="d-md-none">
							</div>
						</a>
					</div>
				</div>
			</div>
		</div>
