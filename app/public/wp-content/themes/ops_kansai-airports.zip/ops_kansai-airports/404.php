<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

?>
<?php get_template_part( 'inc/header' ); ?>

<div style="padding:100px 0; text-align:center; font-size:14px">
	<div style="margin:0 0 20px; font-size:18px; font-weight:bold">404エラー</div>
	このページは削除されたか、又は存在しません。 
</div>


<?php get_template_part( 'inc/footer' ); ?>
