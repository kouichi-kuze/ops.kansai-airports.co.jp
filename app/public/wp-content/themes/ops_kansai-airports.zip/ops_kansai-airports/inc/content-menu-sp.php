
<div id="overlay">
 <ul class="globalNavi">
     <li><a href="<?php echo home_url( '/' ); ?>lp/#lpPlansSec">ご利用プラン</a></li>
     <li><a href="<?php echo home_url( '/' ); ?>lp/#lpAccessSec">アクセス</a></li>
     <li><a href="<?php echo home_url( '/' ); ?>lp/#lpConceptSec">コンセプト</a></li>
     <li><a href="<?php echo get_option('home'); ?>/request/">資料請求</a></li>
     <li><a href="<?php echo get_option('home'); ?>/contact/">内覧予約・お問い合わせ</a></li>
 </ul>
</div><!-- /#overlay -->

<div class="icn-humberger">
  <div>
    <span class="bar-top"></span>
    <span class="bar-middle"></span>
    <span class="bar-bottom"></span>
</div>
</div><!-- /.icn-humberger -->