<ul class="globalNavi pc">
	<li><a href="#lpPlansSec">ご利用プラン</a></li>
	<li><a href="#lpAccessSec">アクセス</a></li>
	<li><a href="#lpConceptSec">コンセプト</a></li>
	<li><a href="<?php echo get_option('home'); ?>/request/">資料請求</a></li>
</ul>