<!-- jQuery CDN --> 
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/vegas/2.5.1/vegas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/assets/js/common.js"></script>