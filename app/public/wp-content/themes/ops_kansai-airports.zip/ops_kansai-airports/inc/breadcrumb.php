<?php
// template-parts/breadcrumb.php
if ( function_exists( 'mytheme_breadcrumb' ) ) {
    mytheme_breadcrumb();
}
?>